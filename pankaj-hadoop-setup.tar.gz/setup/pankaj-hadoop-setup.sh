#!/bin/sh

if test -b /dev/sdb && ! grep -q /dev/sdb /etc/fstab; then
    mke2fs -F -j /dev/sdb
    mount /dev/sdb /mnt
    chmod 755 /mnt
    echo "/dev/sdb	/mnt	ext3	defaults,nofail	0	2" >> /etc/fstab
fi

mkdir /mnt/hadoop
chmod 1777 /mnt/hadoop

grep -o -E 'slave[0-9]+$' /etc/hosts > /usr/local/hadoop-2.8.3/etc/hadoop/slaves

#Mine

cat /usr/local/bashrc >> /users/pchand/.bashrc

cp /usr/local/id_rsa /users/pchand/.ssh
cp /usr/local/id_rsa.pub /users/pchand/.ssh
chmod 666 /users/pchand/.ssh/id_rsa
chmod 666 /users/pchand/.ssh/id_rsa.pub
chown pchand:flinktune-PG0 /users/pchand/.ssh/id_rsa
chown pchand:flinktune-PG0 /users/pchand/.ssh/id_rsa.pub

cat /users/pchand/.ssh/id_rsa.pub >> /users/pchand/.ssh/authorized_keys

. /users/pchand/.bashrc

#sed -i orig -e 's@^export JAVA_HOME.*@export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64@' -e 's@^export HADOOP_CONF_DIR.*@export HADOOP_CONF_DIR=/usr/local/hadoop-2.8.3/etc/hadoop@' /usr/local/hadoop-2.8.3/etc/hadoop/hadoop-env.sh

#if hostname | grep -q namenode; then
#    if ! test -d /mnt/hadoop/current; then
#	/usr/local/hadoop-2.8.3/bin/hadoop namenode -format
#    fi
#    /usr/local/hadoop-2.8.3/sbin/hadoop-daemon.sh --script hdfs start namenode
#elif hostname | grep -q resourcemanager; then
#    /usr/local/hadoop-2.8.3/sbin/yarn-daemon.sh start resourcemanager
#else
#    /usr/local/hadoop-2.8.3/sbin/yarn-daemon.sh start nodemanager
#    /usr/local/hadoop-2.8.3/sbin/hadoop-daemon.sh --script hdfs start datanode
#fi

#if hostname | grep -q namenode; then
#    /usr/local/hadoop-2.8.3/bin/hdfs dfs -mkdir /user
#    /usr/local/hadoop-2.8.3/bin/hdfs dfs -mkdir /tmp
#    /usr/local/hadoop-2.8.3/bin/hdfs dfs -mkdir /tmp/hadoop-yarn
#    /usr/local/hadoop-2.8.3/bin/hdfs dfs -mkdir /tmp/hadoop-yarn/staging
#    /usr/local/hadoop-2.8.3/bin/hdfs dfs -chmod 1777 /tmp
#    /usr/local/hadoop-2.8.3/bin/hdfs dfs -chmod 1777 /tmp/hadoop-yarn
#    /usr/local/hadoop-2.8.3/bin/hdfs dfs -chmod 1777 /tmp/hadoop-yarn/staging
#fi
